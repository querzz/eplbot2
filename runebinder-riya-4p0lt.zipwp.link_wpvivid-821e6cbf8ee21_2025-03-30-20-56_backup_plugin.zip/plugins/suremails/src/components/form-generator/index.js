export { default } from './form-generator';
