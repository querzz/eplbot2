export { default } from './truncated-tooltip-text';
