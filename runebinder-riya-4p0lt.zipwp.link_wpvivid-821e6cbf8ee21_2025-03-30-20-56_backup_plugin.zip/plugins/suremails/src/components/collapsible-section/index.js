export { default } from './collapsible-section';
