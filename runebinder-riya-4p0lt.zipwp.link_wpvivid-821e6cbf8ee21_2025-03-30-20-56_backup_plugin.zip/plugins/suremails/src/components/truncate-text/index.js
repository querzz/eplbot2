export { default } from './truncate-text';
