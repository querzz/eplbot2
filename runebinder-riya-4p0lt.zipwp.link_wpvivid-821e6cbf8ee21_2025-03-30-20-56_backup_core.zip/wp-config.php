<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'zw_xj284wnyad1_jPYS8bZsmcaszYmK' );

/** Database username */
define( 'DB_USER', 'zw_xj284wnyad1_mvmN4eCJeAkMdI' );

/** Database password */
define( 'DB_PASSWORD', 'ydkyhqy0eAZMrUy0e8' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'K_l5~p:]o8.O# ngZEEzJS6gERruDAJ0&/W[y_WO&=U}Fl1%%?-3K&lmL{/2A>tQ' );
define( 'SECURE_AUTH_KEY',   'SSYC*`sUr25U&[x{3r0R[:XxA~|vQg<<MELPzr_tcySg<3!,A. p&sr9 aeOL#3^' );
define( 'LOGGED_IN_KEY',     '}@A#)3vW}L{YKqjnT d{~d+vAR!$4w$FBKx^FttfYr|[SI:@7.b.HpD6>ys4L>Uk' );
define( 'NONCE_KEY',         'eS%.d/qH!#/|WXFF-X,8$Kw0=? );Mhm^H.ltqc9gZCu$C`e-)dM,!]_z</-x|al' );
define( 'AUTH_SALT',         ']E >Wg+?eAsxp71h+=+C/G=vFb}g/MZLCEq`.;o-_l[-M<0R^w2|zC`<-{k^c~E^' );
define( 'SECURE_AUTH_SALT',  '{aRJy${]nVO2^q7)WZizB-TVL!v|[|?Ll-F|~&oG{h*}xtM.Ws,H@%k)_0LJtC^n' );
define( 'LOGGED_IN_SALT',    'cnr%=i1|TbosL{4zad`_G%%2PDV|aU+IeCkR =25Ax-SpCO}4Fii=]VMG^5DP+9s' );
define( 'NONCE_SALT',        'qHd`z}l]B9kq98*5CN9 ?}L#OSO2-d#TkdGP8LH&$S=b|#IR,{=vMgNr !9e!R`D' );
define( 'WP_CACHE_KEY_SALT', 'la>U~@cGz?.;45%<M8Py)>W{M`KFNRD)CjL?#xaNCfGbs:)T&#.l%NPWyfU*$hQ^' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
